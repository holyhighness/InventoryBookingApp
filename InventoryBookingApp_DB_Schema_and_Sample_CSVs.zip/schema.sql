
-- Members Table
CREATE TABLE Members (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT NOT NULL
);

-- Inventory Table
CREATE TABLE Inventories (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Description TEXT,
    TotalCount INTEGER NOT NULL,
    AvailableCount INTEGER NOT NULL
);

-- Bookings Table
CREATE TABLE Bookings (
    BookingRef TEXT PRIMARY KEY,
    MemberId INTEGER NOT NULL,
    InventoryId INTEGER NOT NULL,
    BookingDateTime TEXT NOT NULL,
    FOREIGN KEY (MemberId) REFERENCES Members(Id),
    FOREIGN KEY (InventoryId) REFERENCES Inventories(Id)
);
