# Inventory Booking App - Full Solution

Includes: EF Core, AutoMapper, XUnit, Docker, SQL Schema, CSV Upload Flow.