
#!/bin/bash

# Initialize EB CLI project (run once)
eb init -p "dotnet6" InventoryBookingAppAWS --region us-east-1

# Create environment
eb create InventoryBooking-env

# Deploy application
eb deploy

echo "Deployment Complete. Access URL will be shown above."
