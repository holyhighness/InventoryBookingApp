
#!/bin/bash

# Set variables
RESOURCE_GROUP="InventoryBookingRG"
APP_PLAN="InventoryBookingPlan"
WEBAPP_NAME="inventorybookingapp$RANDOM"

# Create Resource Group
az group create --name $RESOURCE_GROUP --location eastus

# Create App Service Plan
az appservice plan create --name $APP_PLAN --resource-group $RESOURCE_GROUP --sku FREE

# Create Web App
az webapp create --name $WEBAPP_NAME --plan $APP_PLAN --resource-group $RESOURCE_GROUP --runtime "DOTNET|6.0"

# Deploy code (Assumes zipped package)
az webapp deployment source config-zip --resource-group $RESOURCE_GROUP --name $WEBAPP_NAME --src InventoryBookingApp_FullSolution_StarterPack.zip

echo "Deployed to: https://$WEBAPP_NAME.azurewebsites.net"
